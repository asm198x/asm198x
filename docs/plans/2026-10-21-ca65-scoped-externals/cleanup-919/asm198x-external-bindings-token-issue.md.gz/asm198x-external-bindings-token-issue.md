ca65 visibility operands lose the distinction between a physical register token and an identifier created by `.ident`.

```asm
.import A
.byte 7
```

Native ca65 V2.18 refuses line 1 with `Identifier expected`. The qualified #916 Asm198x producer (`5408b4790fa88f22c127201f70f0d7e57ecde3cd`, executable SHA-256 `71d93430e8ee2cea6f3f98a85d5ec50cf7e07bea31f1253d16b31164050daaa3`) accepts and emits `07`. `.global A` has the same false acceptance.

The valid counterpart is `.import .ident("A")` (or `.global .ident("A")`), followed by `.byte 7`: native accepts and emits `07`. Rejecting every expanded spelling `A` would break these valid inputs. Constant-definition reserved-name checks are not a substitute for visibility-operand token admission.

Retained six-case native sources/configs/process streams and the frozen producer comparison are in [visibility-token-native.json](https://github.com/asm198x/asm198x/blob/fix/ca65-scoped-external-bindings/docs/plans/2026-10-21-ca65-scoped-externals/visibility-token-native.json) and [visibility-token-before.json](https://github.com/asm198x/asm198x/blob/fix/ca65-scoped-external-bindings/docs/plans/2026-10-21-ca65-scoped-externals/visibility-token-before.json). Native tool identities and both generated/physical forms are retained.

Preserve per-operand identifier provenance through the existing text/reader seams. Probe import/global/export, defined generated-register names, lists mixing physical/generated operands, includes/macros and lazy bodies. Verify native status and accepted bytes, original diagnostics/provenance, formatter/debug round trips and unchanged outputs on refusal. Avoid whole-line “contains .ident” exceptions. Keep this lexical distinction separate from #810's scoped binding and external address-size contract.
