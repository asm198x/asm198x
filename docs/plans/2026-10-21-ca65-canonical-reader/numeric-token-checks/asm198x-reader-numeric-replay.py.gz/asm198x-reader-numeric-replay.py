import hashlib,json,subprocess
from pathlib import Path
base=Path('/private/tmp/asm198x-faraddr-producer');out=Path('/private/tmp/asm198x-reader-numeric-replay');out.mkdir(exist_ok=False)
meta=json.loads((base/'replay-summary.json').read_text());assert len(meta)==35 and sum(r['cases'] for r in meta)==5659
summary=[]
for row in meta:
 label=row['label'];facts=Path(row['facts']);assert hashlib.sha256(facts.read_bytes()).hexdigest()==row['facts_sha256']
 old=base/(('conditional' if label=='conditional-context' else label)+'-after.json');before=json.loads(old.read_text())['results'];result=out/(label+'-after.json')
 command=['python3','docs/plans/2026-10-20-ca65-string-token-provenance/consumer_compare.py','/private/tmp/asm198x-scalar-build/debug/asm198x',str(result),'--facts',str(facts)]+(['--flat'] if label=='strings-flat-native' else [])
 with (out/(label+'.log')).open('w') as log:subprocess.run(command,check=True,timeout=180,stdout=log,stderr=subprocess.STDOUT)
 after=json.loads(result.read_text())['results'];assert len(before)==len(after)==row['cases']
 b={r['name']:r['matches_native'] for r in before};a={r['name']:r['matches_native'] for r in after};assert b.keys()==a.keys();assert b==a,(label,[n for n in b if b[n]!=a[n]])
 summary.append(dict(label=label,cases=len(after),native_matches=sum(a.values()),lost_matches=[]));print(label,len(after),sum(a.values()),flush=True)
assert sum(r['native_matches'] for r in summary)==5417
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
