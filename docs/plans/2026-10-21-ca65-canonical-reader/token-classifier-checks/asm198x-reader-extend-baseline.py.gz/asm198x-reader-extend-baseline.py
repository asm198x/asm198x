import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/private/tmp/asm198x-faraddr-producer');meta=json.loads((root/'replay-summary.json').read_text());assert len(meta)==29
compare='docs/plans/2026-10-20-ca65-string-token-provenance/consumer_compare.py'
ref='57687f41a96296e3600f1488a0d42c018b9e2da6'
for label,source,count,matches in [('generated-fields','generated',40,40),('repeat-names','repeat',18,15),('scalar-fields','scalar',320,218),('file-fields','file',200,137),('configured-faraddr',None,190,190),('canonical-fields',None,100,91)]:
 facts=root/'facts'/(label+'.json');assert not facts.exists()
 if source:
  path='docs/plans/2026-10-21-ca65-linked-faraddr/qualification-925/asm198x-faraddr-extra__'+source+'-native.json.gz'
  data=gzip.decompress(subprocess.check_output(['git','show',ref+':'+path]));original='https://github.com/asm198x/asm198x/blob/'+ref+'/'+path
 else:
  path='docs/plans/2026-10-21-ca65-'+('linked-faraddr' if label=='configured-faraddr' else 'canonical-reader')+'/native.json';data=Path(path).read_bytes();original=path
 facts.write_bytes(data);assert len(json.loads(data)['cases'])==count
 result=root/(label+'-after.json')
 subprocess.run(['python3',compare,str(root/'asm198x'),str(result),'--facts',str(facts)],check=True,timeout=120)
 rows=json.loads(result.read_text())['results'];assert len(rows)==count and sum(x['matches_native'] for x in rows)==matches,label
 meta.append(dict(label=label,facts=str(facts),baseline=str(result),cases=count,before_matches=matches,after_matches=matches,lost_matches=[],facts_sha256=hashlib.sha256(data).hexdigest(),original_facts=original))
assert len(meta)==35 and sum(r['cases'] for r in meta)==5659
(root/'replay-summary.json').write_text(json.dumps(meta,indent=2)+'\n');print('Frozen #925 baseline: 35 matrices / 5659 cases')
