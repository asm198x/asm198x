import hashlib
import json
import re
from pathlib import Path

p = Path('/private/tmp/asm198x-scalar-final-local-package')
r = json.loads((p / 'report.json').read_text())
w = json.loads((p / 'wrong-bytes.json').read_text())
c = json.loads((p / 'corrupt-archive.json').read_text())
old = json.loads(Path('/private/tmp/asm198x-scalar-final-predecessor-package.json').read_text())
identity = json.loads(Path('/private/tmp/asm198x-scalar-final-producer/identity.json').read_text())
assert r['qualified'] and len(r['results']) == 105 and all(x['status'] == 'pass' for x in r['results'])
assert r['checkout_commit'] == identity['commit'] and r['executable_sha256'] == identity['executable_sha256']
assert r['source_lock_scope'] == 'artifact-only' and r['source_lock'] is None
assert r['archive_sha256'] == hashlib.sha256((p / r['archive']).read_bytes()).hexdigest()
assert not w['qualified'] and len(w['results']) == 105 and {x['name'] for x in w['results'] if x['status'] != 'pass'} == {'reference_bytes', 'determinism', 'structured_success'}
assert w['archive_sha256'] == r['archive_sha256'] and w['executable_sha256'] == r['executable_sha256']
assert not c['qualified'] and c['error'] == 'SHA-256 mismatch for ' + r['archive']
assert not old['qualified'] and len(old['results']) == 105 and [x['name'] for x in old['results'] if x['status'] != 'pass'] == ['ca65_scalar_context']
facts = json.loads(Path('crates/asm198x/tests/fixtures/ca65-scalar-context.json').read_text())['cases']
case = next(x for x in r['results'] if x['name'] == 'ca65_scalar_context')
assert len(facts) == 320 and len(case['runs']) == 1136
cursor = 0
for fact in facts:
    accepted = fact['native'][-1]['exit'] == 0
    stride = 4 if accepted else 1
    group = case['runs'][cursor:cursor + stride]
    cursor += stride
    assert len(group) == stride and all(x['signal'] is None and not x.get('error') for x in group), fact['name']
    assert [x['exit'] for x in group] == ([0, 0, 0, 0] if accepted else [1]), fact['name']
    if accepted:
        assert group[1]['stdout'] == group[2]['stdout'], fact['name']
        for stage in [group[0], group[3]]:
            assert json.loads(stage['stdout'])['bytes'] == list(bytes.fromhex(fact['native_hex'])), fact['name']
    if 'expected_messages' in fact:
        for stage in ([group[0], group[3]] if accepted else [group[0]]):
            payload = json.loads(stage['stdout'])
            actual = [dict(message=m['message'], kind=m.get('kind', 'Warning')) for m in payload['warnings']] if accepted else [dict(message=e['message'], kind=e['severity']) for e in payload]
            assert actual == fact['expected_messages'], fact['name']
assert cursor == 1136
roots = set()
for report in [r, w, old]:
    report_roots = set()
    for cohort in report['results']:
        for run in cohort.get('runs', []):
            cwd = Path(run['cwd'])
            candidates = [ancestor for ancestor in [cwd, *cwd.parents] if ancestor.name.startswith('asm198x-candidate-')]
            assert len(candidates) == 1, str(cwd)
            report_roots.add(str(candidates[0]))
    assert len(report_roots) == 1, report_roots
    roots.update(report_roots)
assert len(roots) == 3 and not any(Path(x).exists() for x in roots), roots
s = Path('/private/tmp/asm198x-scalar-final-workspace.log').read_text()
rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', s)
assert len(rows) == 110 and all(x[0] == 'ok' for x in rows)
summary = dict(source=identity, local_package_scope='artifact-only', archive_sha256=r['archive_sha256'], cohorts=105, scalar_cases=320, scalar_processes=1136, workspace_binaries=len(rows), workspace_passed=sum(int(x[1]) for x in rows), workspace_failed=sum(int(x[2]) for x in rows), workspace_ignored=sum(int(x[3]) for x in rows), corruption_controls=2, predecessor_failures=['ca65_scalar_context'], scratch_roots_removed=sorted(roots), inspection_correction='Initial root-cardinality assertion counted the upstream child directory separately. Every run is now checked against its unique candidate root, and all three roots are verified removed.')
assert summary['workspace_passed'] == 1644 and summary['workspace_failed'] == 0 and summary['workspace_ignored'] == 38
(p / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
