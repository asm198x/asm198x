import concurrent.futures,json,subprocess,sys,time
from pathlib import Path
prefix,head=sys.argv[1:]
def api(path):return json.loads(subprocess.run(['gh','api','repos/asm198x/asm198x/'+path],capture_output=True,text=True,timeout=35,check=True).stdout)
for i in range(100):
 if Path(prefix+'-stop').exists():raise SystemExit('polling stopped without qualification')
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  checks,runs,status=pool.map(api,[f'commits/{head}/check-runs?per_page=100',f'actions/runs?head_sha={head}&per_page=100',f'commits/{head}/status'])
 assert checks['total_count']==len(checks['check_runs'])<=100
 assert runs['total_count']==len(runs['workflow_runs'])<=100
 allruns=checks['check_runs']+runs['workflow_runs'];assert all(r['head_sha']==head for r in allruns)
 bad=[(r['name'],r['conclusion']) for r in allruns if r['status']=='completed' and r['conclusion'] not in ['success','neutral','skipped']];assert not bad,bad
 pending=[r['name'] for r in allruns if r['status']!='completed'];names={r['name'] for r in runs['workflow_runs']}
 Path(prefix+'-ci.json').write_text(json.dumps(dict(checks=checks,runs=runs,status=status),indent=2)+'\n')
 print(i,len(checks['check_runs']),len(runs['workflow_runs']),'pending',pending,flush=True)
 if len(checks['check_runs'])>=29 and names=={'CI','Release','Release PR','Candidate packages','PR title'} and not pending and (not status['statuses'] or status['state']=='success'):
  expected=set(json.loads(Path('/private/tmp/asm198x-required-checks-shared.json').read_text())['names'])
  assert {r['name'] for r in checks['check_runs']}==expected
  break
 time.sleep(30)
else:raise SystemExit('gate timed out')
print('All exact-head checks and workflows complete',head,flush=True)
