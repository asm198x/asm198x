import concurrent.futures
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

repo = Path('/Users/stevehill/Projects/198x/Asm198x/asm198x-ca65-text-consumers')
baseline = Path('/private/tmp/asm198x-data-context-v3-producer')
root = Path('/private/tmp/asm198x-scalar-replay')
binary = Path('/private/tmp/asm198x-scalar-build/debug/asm198x')
matrices = json.loads((baseline / 'replay-summary.json').read_text())


def replay(item):
    label = item['label']
    facts = Path(item['facts'])
    assert hashlib.sha256(facts.read_bytes()).hexdigest() == item['facts_sha256']
    before_path = baseline / (('conditional' if label == 'conditional-context' else label) + '-after.json')
    before = json.loads(before_path.read_text())['results']
    output = root / (label + '-after.json')
    data = json.loads(facts.read_text())
    after = []
    with tempfile.TemporaryDirectory(prefix='asm198x-scalar-replay-case-') as td:
        case_root = Path(td)
        for name, contents in data.get('files', {}).items():
            destination = case_root / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(contents)
        for fact, previous in zip(data['cases'], before):
            assert fact['name'] == previous['name']
            (case_root / 'input.s').write_text(fact['source'])
            (case_root / 'input.cfg').write_text(fact['config'])
            (case_root / 'out.bin').unlink(missing_ok=True)
            argv = [str(binary), *previous['argv'][1:]]
            result = subprocess.run(argv, cwd=case_root, capture_output=True, text=True, check=False, timeout=5)
            image = case_root / 'out.bin'
            raw = image.read_bytes().hex() if image.exists() else None
            matches = (result.returncode == 0) == (fact['native'][-1]['exit'] == 0) and (result.returncode != 0 or raw == fact['native_hex'])
            after.append(dict(name=fact['name'],argv=argv,exit=result.returncode,stdout=result.stdout,stderr=result.stderr,hex=raw,matches=matches))
    output.write_text(json.dumps(dict(binary=str(binary), sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), results=after),indent=2)+'\n')
    assert len(before) == len(after) == item['cases']
    assert [x['name'] for x in before] == [x['name'] for x in after]
    lost = [b['name'] for b, a in zip(before, after) if b['matches_native'] and not a['matches']]
    fixed = [b['name'] for b, a in zip(before, after) if not b['matches_native'] and a['matches']]
    row = dict(label=label, cases=len(after), before_matches=sum(x['matches_native'] for x in before), after_matches=sum(x['matches'] for x in after), lost_matches=lost, fixed=fixed, facts=str(facts), facts_sha256=item['facts_sha256'])
    print(label, row['before_matches'], '->', row['after_matches'], 'lost', lost, flush=True)
    return row


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    results = list(executor.map(replay, matrices))
(root / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
assert len(results) == 29 and sum(x['cases'] for x in results) == 4791
assert not any(x['lost_matches'] for x in results)
