import importlib.util
from pathlib import Path
ROOT=Path('/Users/stevehill/Projects/198x/Asm198x/asm198x-ca65-text-consumers')
bodies={
 'repeat_ident':'.repeat 2,.ident("INDEX")\n.byte INDEX\n.endrepeat\n',
 'repeat_selector':'.repeat 2,.left(1,{INDEX})\n.byte INDEX\n.endrepeat\n',
 'repeat_generated_read':'VALUE=2\n.repeat .const(VALUE),.ident(.sprintf("INDEX%d",.ref(VALUE)))\n.byte INDEX1,.ref(VALUE)\n.endrepeat\n',
 'repeat_generated_own_read':'VALUE=2\n.repeat 2,.ident(.sprintf("INDEX%d",VALUE))\n.byte INDEX2,.ref(VALUE)\n.endrepeat\n',
 'assert_ident':'.assert 1,.ident("error"),"ok"\n.byte 9\n',
 'assert_selector':'.assert 1,.left(1,{error}),"ok"\n.byte 9\n',
 'assert_action_read':'VALUE=2\n.assert 1,.ident(.sprintf("%s",.concat("err",.string(VALUE),"or"))),"ok"\n.byte .ref(VALUE)\n',
 'assert_tail':'.assert 1,error,"ok",.sprintf("%d",MISSING)\n.byte 9\n',
}
files={};prepared={}
for name,body in bodies.items():
 for context in ['direct','included','macro','inactive','unused']:
  key=name+'_'+context
  if context=='included':files[key+'.inc']=body;source=f'.include "{key}.inc"\n'
  elif context in ['macro','unused']:source='.macro run\n'+body+'.endmacro\n'+('run\n' if context=='macro' else '.byte 9\n')
  elif context=='inactive':source='.if 0\n'+body+'.endif\n.byte 9\n'
  else:source=body
  prepared[key]=source
spec=importlib.util.spec_from_file_location('capture',ROOT/'docs/plans/2026-10-19-ca65-scope-binding/probe.py');assert spec and spec.loader
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.cases=lambda:prepared;c.FILES=files;c.main()
