Merged in #911 after all 29 checks and five native archive targets passed on the qualified source.

We validate dbyt as unsigned 16-bit big-endian data and dword as unsigned 32-bit little-endian data through the existing Sized operation. The new cohort runs all 104 supported cases and 260 commands per target. All 97 archive cohorts and both corruption controls passed on each target. The four unchanged inactive-source refusals remain explicit under #895; the complete 108-case native audit retains them.

The merged tree matches the qualified source. Native/local evidence is in `docs/plans/2026-10-20-flat-ca65-data-widths/`; complete five-host reports are retained in its follow-up qualification folder. The independent addr and per-element counter gaps remain #909/#910.
