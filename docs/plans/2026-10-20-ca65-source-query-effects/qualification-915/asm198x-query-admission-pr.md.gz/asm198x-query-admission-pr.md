Selected ca65 conditional queries could fold away an undefined symbol and incorrectly assemble successfully. Preserve ordinary dependencies and complete source spans through the existing final scope resolver. Forward definitions, scoped outward fallback and query-only names keep native behavior; refusals preserve existing outputs.

The 54-case audit fixes 12 wrong acceptances, with 51 supported controls now permanent CLI and required package coverage. The formerly excluded classifier refusal also passes, bringing that fixture to all 314 native cases. The three logical `.const` text-expansion controls and ordered source reads remain under #795. Eighteen supplementary short-circuit and `.ifnconst` controls also match native ca65.

Validation: 1,639 Rust/Lua tests passed (38 ignored), 115 Node checks, Clippy/fmt, docs/version checks, all 2,194 previous native replay cases without a lost match, and a fresh 564-byte 4510 execution. All 29 required CI checks pass. All five actual native archives pass 101 cohorts, including 156 query commands and 1,229 classifier commands each, with both corruption controls verified. The initial macOS Lua job acquired no runner; its capacity-failure annotations are retained and the same-commit retry passed.

Refs #795.
