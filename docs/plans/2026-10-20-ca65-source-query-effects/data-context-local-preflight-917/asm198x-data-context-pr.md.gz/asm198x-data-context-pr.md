We now read ca65 data-list queries at their source positions. For `VALUE=2` followed by `.byte .ref(VALUE),.const(VALUE),.ref(VALUE)`, output changes from `000100` to native `000101`. Numeric string arguments, scoped queries and token selectors use the same checked live context after ordinary label binding.

The retained 500-case ca65/ld65 audit fixes 183 predecessor differences and covers data widths/extractors, byte strings, selectors, current labels, scopes, includes/macros and lazy bodies. The required `ca65_data_context` candidate cohort checks native bytes, structured output, formatter/debug round trips and refusal preservation; omitting it fails qualification.

Library/focused tests, all-target Clippy, formatting, 115 Node checks and documentation/version checks pass. Complete workspace, fresh 4510 and native archive qualification will be recorded before merge. Preflight failures remain separately labelled with the native evidence used to correct legacy test expectations.

Part of #795. Repeat counts and other numeric consumers remain; ordinary label/procedure sizes remain #798.
