import concurrent.futures
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

head = "48e2428d565e3c7a010ae50963198b47b76e9650"
producer = Path("/private/tmp/asm198x-data-context-v2-producer")
identity = json.loads((producer / "identity.json").read_text())
assert identity["commit"] == head
binary = producer / "asm198x"
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity["executable_sha256"]
root = Path("/private/tmp/asm198x-data-context-v2-local-package")
root.mkdir(exist_ok=False)
name = "asm198x-aarch64-apple-darwin.tar.xz"
archive = root / name
with tarfile.open(archive, "w:xz") as tar:
    tar.add(binary, arcname="asm198x-aarch64-apple-darwin/asm198x")
(root / (name + ".sha256")).write_text(hashlib.sha256(archive.read_bytes()).hexdigest() + "  " + name + "\n")
plan = "/private/tmp/asm198x-text-consumers-plan.json"
base = ["node", "scripts/test-candidate-package.cjs", plan, "aarch64-apple-darwin"]

def check(kind):
    directory = "/private/tmp/asm198x-conditional-context-final-local-package" if kind == "predecessor" else str(root)
    report = root / (kind + ".json")
    control = {"wrong-bytes": ["--control-wrong-bytes"], "corrupt-archive": ["--control-corrupt-archive"]}.get(kind, [])
    p = subprocess.run([*base, directory, str(report), *control], capture_output=True, text=True, timeout=1800, check=False, env={**os.environ, "GITHUB_SHA": head})
    (root / (kind + ".log")).write_text(p.stdout + p.stderr)
    result = json.loads(report.read_text())
    assert p.returncode == (0 if kind == "report" else 1), (kind, p.returncode, p.stderr)
    assert result["qualified"] == (kind == "report"), kind
    if kind == "corrupt-archive":
        assert result["error"] == "SHA-256 mismatch for " + name
    else:
        assert len(result["results"]) == 103
        failures = {r["name"] for r in result["results"] if r["status"] != "pass"}
        expected = set() if kind == "report" else {"ca65_data_context"} if kind == "predecessor" else {"reference_bytes", "determinism", "structured_success"}
        assert failures == expected, (kind, failures)
        assert result["source_lock_scope"] == "artifact-only"
        if kind == "report":
            cohort = next(r for r in result["results"] if r["name"] == "ca65_data_context")
            assert len(cohort["runs"]) == 1853
    print(kind, "verified", flush=True)
    return {"control": kind, "exit": p.returncode, "report_sha256": hashlib.sha256(report.read_bytes()).hexdigest()}

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    results = list(executor.map(check, ["report", "wrong-bytes", "corrupt-archive", "predecessor"]))
(root / "controls-summary.json").write_text(json.dumps(results, indent=2) + "\n")
