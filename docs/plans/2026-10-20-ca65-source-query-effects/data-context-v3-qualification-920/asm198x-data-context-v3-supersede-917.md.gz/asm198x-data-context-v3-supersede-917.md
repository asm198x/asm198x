Draft: this change is not qualified for merge. We are finishing #810 first, then returning to this data slice under #795.

The data reader matches all 515 retained native ca65/ld65 controls, fixes 186 predecessor differences and preserves every previous match across 2,466 cases. The full workspace and actual archive qualification catch `import_queries_before_definition`: the now-readable scoped `.const` exposes the existing import-definition guard bug, incorrectly accepting a source native ca65 refuses.

A narrow scoped-guard trial regressed nine prior import/export controls. It has been preserved and rolled back. No failed check is waived and no fixture is weakened. The approved next scope is the coupled #810 contract: declaration allocation, same-file external resolution and source address-size behavior. [Concrete approved proposal](https://github.com/asm198x/asm198x/blob/audit/ca65-data-context-917/docs/plans/2026-10-20-ca65-source-query-effects/scoped-imports-before-data-design.md).

The audit branch retains the failed local/four uploaded native reports, original/rejected source refs, complete comparison evidence and positive cleanup receipts. The Intel macOS job was cancelled and is not counted as qualification. The next 50-case #795 consumer audit retains 30 active differences; this data slice does not complete #795. Ordinary label/procedure sizes remain #798.

Superseded by checked and merged #920 (`15a2c6dc3492a88f77495e4fa162189e43870c82`). The implementation was reapplied after #919 fixed scoped external binding. All 515 data controls, the full 1,643-test workspace suite and all five actual 104-cohort native reports pass. The rejected original source branch and its audit evidence remain retained.
