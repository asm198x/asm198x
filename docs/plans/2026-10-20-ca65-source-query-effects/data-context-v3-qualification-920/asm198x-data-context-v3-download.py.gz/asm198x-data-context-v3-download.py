import json, subprocess, time
from pathlib import Path
run="39586939162"
root=Path("/private/tmp/asm198x-data-context-v3-candidates")
root.mkdir(exist_ok=False)
expected={"candidate-qualification-"+t+"-1" for t in ["aarch64-apple-darwin","x86_64-apple-darwin","x86_64-pc-windows-msvc","x86_64-unknown-linux-gnu","aarch64-unknown-linux-gnu"]}
seen=set()
for attempt in range(70):
 result=subprocess.run(["gh","api",f"repos/asm198x/asm198x/actions/runs/{run}/artifacts?per_page=100"],capture_output=True,text=True,timeout=35,check=True)
 data=json.loads(result.stdout)
 assert data["total_count"]==len(data["artifacts"])<=100
 Path("/private/tmp/asm198x-data-context-v3-artifacts.json").write_text(json.dumps(data,indent=2)+"\n")
 for artifact in data["artifacts"]:
  name=artifact["name"]
  assert name in expected and not artifact["expired"],name
  if name in seen:continue
  subprocess.run(["gh","run","download",run,"--repo","asm198x/asm198x","--name",name,"--dir",str(root/name)],check=True,timeout=120)
  assert (root/name/"report.json").is_file()
  seen.add(name)
  print("downloaded",name,flush=True)
 if seen==expected:break
 time.sleep(30)
else:raise RuntimeError("native reports did not all arrive within 35 minutes")
assert len(list(root.glob("*/report.json")))==5
