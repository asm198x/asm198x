import hashlib,json,subprocess,sys
from pathlib import Path
prefix,head,run_id,fixture,case_name,expected_count,expected_total=sys.argv[1:];expected_count=int(expected_count);expected_total=int(expected_total)
def git(*args):return subprocess.run(['git','-c','core.fsmonitor=false',*args],capture_output=True,check=True).stdout
meta=json.loads(subprocess.run(['node','-e',"const cp=require('node:child_process');const Module=require('node:module');const path=require('node:path');const filename=path.resolve('scripts/test-candidate-package.cjs');const m=new Module(filename,module);m.filename=filename;m.paths=Module._nodeModulePaths(path.dirname(filename));m._compile(cp.execFileSync('git',['show',process.argv[1]+':scripts/test-candidate-package.cjs'],{encoding:'utf8'}),filename);const x=m.exports;process.stdout.write(JSON.stringify({targets:x.targets,cases:x.requiredCases}))",head],capture_output=True,text=True,check=True).stdout)
lock=hashlib.sha256(git('show',head+':Cargo.lock')).hexdigest();facts=json.loads(Path(fixture).read_text())['cases'];assert len(facts)==expected_count>0
if case_name=='ca65_hex_suffix':
 facts += [dict(f,dialect=d) for d in ['65816','huc6280'] for f in list(facts) if f['name'] in ['constant_0FFh','difference_100000000h']]
paths=list(Path(prefix+'-candidates').glob('*/report.json'));assert len(paths)==5
sources=set();targets=set();summary=[]
for path in paths:
 r=json.loads(path.read_text());targets.add(r['target']);sources.add(r['checkout_commit'])
 assert r['qualified'] is True and r['source_lock_scope']=='verified-producer-lock'
 assert len(r['results'])==len(meta['cases'])==expected_total
 assert {c['name'] for c in r['results']}==set(meta['cases']) and all(c['status']=='pass' for c in r['results'])
 case=next(c for c in r['results'] if c['name']==case_name)
 expected_runs=sum(4 if case_name in {'ca65_scoped_constants','ca65_scope_repetition','ca65_include_streams','ca65_text_capture','ca65_macro_introspection','ca65_constant_names','ca65_cheap_constants','ca65_reserved_constants','ca65_scope_anchors','ca65_label_delimiters','ca65_macro_definition_labels','ca65_record_allocators','ca65_deferred_aliases','ca65_scope_binding','ca65_unused_cycles','ca65_enum_expressions','ca65_zp_output','ca65_bss_warnings','ca65_scoped_exports','ca65_org_labels','ca65_origin_bounds','ca65_hex_suffix','ca65_absolute_counter','ca65_absolute_debug','ca65_numeric_conversion','ca65_numeric_admission','ca65_repeat_end','ca65_reserved_labels','ca65_labelled_end','ca65_generated_blocks','ca65_labelled_scopes','ca65_text_call_spacing','ca65_ident_names','ca65_cheap_root','ca65_generated_name_constancy','ca65_generated_macros','ca65_token_bound_types','ca65_string_bytes','ca65_string_consumers','ca65_flat_string_bytes','ca65_literal_boundaries','ca65_text_consumers','ca65_quoted_admission','ca65_character_operands','ca65_huc_macro_format','ca65_flat_macro_diagnostics','ca65_flat_faraddr','ca65_flat_wide_data','ca65_flat_addresses','ca65_flat_element_counter','ca65_source_constancy','ca65_query_admission','ca65_conditional_context'} and (f['native'][-1]['exit']==0 or f.get('format_error')) and not f.get('assembly_gaps') and not f.get('formatter_gap') else 1 for f in facts)
 if case_name=='ca65_format_includes':expected_runs=4*len(facts)
 if case_name=='ca65_huc_macro_format':expected_runs+=2
 if case_name=='ca65_absolute_debug':expected_runs+=19
 assert len(case['runs'])==expected_runs
 cursor=0
 for fact in facts:
  actual=case['runs'][cursor];accepted=fact['native'][-1]['exit']==0 and not fact.get('assembly_gaps')
  assert (actual['exit']==0)==accepted,fact['name']
  assert actual['exit']==(0 if accepted else 1),fact['name']
  stride=4 if case_name in {'ca65_scoped_constants','ca65_scope_repetition','ca65_include_streams','ca65_text_capture','ca65_macro_introspection','ca65_constant_names','ca65_cheap_constants','ca65_reserved_constants','ca65_scope_anchors','ca65_label_delimiters','ca65_macro_definition_labels','ca65_record_allocators','ca65_deferred_aliases','ca65_scope_binding','ca65_unused_cycles','ca65_enum_expressions','ca65_zp_output','ca65_bss_warnings','ca65_scoped_exports','ca65_org_labels','ca65_origin_bounds','ca65_hex_suffix','ca65_absolute_counter','ca65_absolute_debug','ca65_numeric_conversion','ca65_numeric_admission','ca65_repeat_end','ca65_reserved_labels','ca65_labelled_end','ca65_generated_blocks','ca65_labelled_scopes','ca65_text_call_spacing','ca65_ident_names','ca65_cheap_root','ca65_generated_name_constancy','ca65_generated_macros','ca65_token_bound_types','ca65_string_bytes','ca65_string_consumers','ca65_flat_string_bytes','ca65_literal_boundaries','ca65_text_consumers','ca65_quoted_admission','ca65_character_operands','ca65_huc_macro_format','ca65_flat_macro_diagnostics','ca65_flat_faraddr','ca65_flat_wide_data','ca65_flat_addresses','ca65_flat_element_counter','ca65_source_constancy','ca65_query_admission','ca65_conditional_context'} and (accepted or fact.get('format_error')) and not fact.get('formatter_gap') else 1
  if case_name=='ca65_format_includes':stride=4
  stages=case['runs'][cursor:cursor+stride]
  assert all(v.get('signal') is None and not v.get('error') for v in stages)
  if stride==4 and accepted:
   if case_name=='ca65_format_includes':assert [v['exit'] for v in stages]==([0,0,0,0] if accepted else [1,0,0,1])
   else:assert all(v['exit']==0 for v in stages)
   assert stages[1]['argv'][1:4]==['fmt','--dialect',fact.get('dialect','ca65')]
   assert stages[1]['stdout']==stages[2]['stdout'],fact['name']
   assert 'scope-formatted.s' in stages[3]['argv']
   if case_name=='ca65_bss_warnings':
    for stage in [stages[0],stages[3]]:
     payload=json.loads(stage['stdout']);assert sum('contains initialized data' in w['message'] for w in payload['warnings'])==fact['native_warning_count'],fact['name']
  if case_name=='ca65_huc_macro_format':
   import re
   definitions=lambda source:[m.group(1) for m in re.finditer(r'(?mi)^\s*\.(?:macro|mac)\s+(\S+)',source)]
   def calls(source,names):
    total=0
    for line in source.splitlines():
     words=line.split()
     if words and words[0].endswith(':'):words=words[1:]
     total+=bool(words and words[0] in names)
    return total
   for stage in [stages[0],stages[3]]:
    assert json.loads(stage['stdout'])['bytes']==list(bytes.fromhex(fact['native_hex'])),fact['name']
   names=definitions(fact['source']);assert names and definitions(stages[1]['stdout'])==names
   assert calls(stages[1]['stdout'],names)==calls(fact['source'],names)
   for marker in ['MISSING','.repeat','.endrepeat','missing.inc']:
    if marker in fact['source']:assert marker in stages[1]['stdout'],fact['name']
  if case_name in {'ca65_flat_macro_diagnostics','ca65_flat_faraddr','ca65_flat_wide_data','ca65_flat_addresses','ca65_flat_element_counter','ca65_source_constancy','ca65_query_admission','ca65_conditional_context'}:
   if accepted:
    for stage in [stages[0],stages[3]]:
     assert json.loads(stage['stdout'])['bytes']==list(bytes.fromhex(fact['native_hex'])),fact['name']
   else:
    payload=json.loads(stages[0]['stdout']);assert isinstance(payload,list) and payload,fact['name']
    if fact.get('native_error'):
     expected=fact['native_error'];span=payload[0]['span']
     assert span['path'].replace(chr(92),'/').rsplit('/',1)[-1]==expected['path'] and span['line']==expected['line'],fact['name']
    if fact.get('expected_context'):
     expected=fact['expected_context'];span=payload[0]['span']
     basename=lambda value:value.replace(chr(92),'/').rsplit('/',1)[-1]
     assert basename(span['path'])==expected['path'] and span['line']==expected['line'],fact['name']
     assert [frame['macro_name'] for frame in span['expansion_frames']]==expected['frames'],fact['name']
     for frame in span['expansion_frames']:
      for key in ['defined_at','invoked_at']:assert basename(frame[key]['path'])==expected['path'],fact['name']
      assert frame['defined_at']['line']==expected['definition_lines'][frame['macro_name']],fact['name']
  if case_name in {'ca65_query_admission','ca65_conditional_context'} and 'query_error' in fact:
   span=json.loads(stages[0]['stdout'])[0]['span']; expected=fact['query_error']
   basename=lambda value:value.replace(chr(92),'/').rsplit('/',1)[-1]
   assert basename(span['path'])==('cpu.s' if expected['path']=='input.s' else expected['path']),fact['name']
   assert span['line']==expected['line'],fact['name']
   assert [frame['macro_name'] for frame in span['expansion_frames']]==expected['frames'],fact['name']
  if case_name=='ca65_flat_element_counter' and not accepted:
   assert fact.get('format_error') is True and stride==4
   assert stages[1]['exit']==stages[2]['exit']==0 and stages[1]['stdout']==stages[2]['stdout']
   assert stages[3]['exit']==1
   span=json.loads(stages[3]['stdout'])[0]['span'];expected=fact['native_error']
   filename='scope-formatted.s' if expected['path']=='input.s' else expected['path']
   assert span['path'].replace(chr(92),'/').rsplit('/',1)[-1]==filename and span['line']==expected['line'],fact['name']
  if case_name=='ca65_character_operands':
   for stage in ([stages[0],stages[3]] if stride==4 else [stages[0]]):
    payload=json.loads(stage['stdout'])
    if accepted:assert payload['bytes']==list(bytes.fromhex(fact['native_hex'])),fact['name']
    else:
     assert isinstance(payload,list) and payload[0]['span']['path']=='cpu.s',fact['name']
     assert payload[0]['span']['line']==fact['native_error_line'],fact['name']
     if fact['name'].endswith('_macro') and '_bad_character_' not in fact['name'] and '_open_string_' not in fact['name']:assert payload[0]['span']['expansion_frames'],fact['name']
  if case_name=='ca65_quoted_admission':
   for stage in ([stages[0],stages[3]] if stride==4 else [stages[0]]):
    payload=json.loads(stage['stdout'])
    if accepted:
     assert payload['bytes']==list(bytes.fromhex(fact['native_hex'])),fact['name']
    else:
     assert isinstance(payload,list) and payload and payload[0]['span']['path']=='cpu.s',fact['name']
     if not fact.get('assembly_gaps'):assert payload[0]['span']['line']==fact['native_error_line'],fact['name']
     else:assert fact['name']=='ascii_44_direct' and fact['assembly_gaps']==[900]
  if case_name=='ca65_text_consumers':
   for stage in ([stages[0],stages[3]] if stride==4 else [stages[0]]):
    payload=json.loads(stage['stdout']);entries=payload['warnings'] if isinstance(payload,dict) else payload
    assert isinstance(entries,list)
    expected=fact['expected_messages']
    if expected is not None:assert [entry['message'] for entry in entries]==expected,(fact['name'],'message payload')
    else:assert fact['audit']=='assertion' and fact['native'][-1]['exit']!=0
    assert 'ca65-string:' not in stage['stdout'] and 'ca65-string:' not in stage['stderr']
    if not isinstance(payload,dict):
     assert entries
     for entry in entries:
      assert entry['span']['path']=='cpu.s'
      if fact['name'].startswith('macro_body_'):assert entry['span']['expansion_frames']
  cursor+=stride
 if case_name=='ca65_huc_macro_format':
  errors=json.loads(Path(fixture).read_text())['error_cases'];assert len(errors)==2
  for fact in errors:
   actual=case['runs'][cursor];cursor+=1;assert actual['exit']==1 and actual.get('signal') is None and not actual.get('error')
   span=json.loads(actual['stdout'])[0]['span'];assert span['path'].replace('\\','/').rsplit('/',1)[-1]=='broken.inc' and span['line']==4
  for cohort,filename in [('ca65_numeric_admission','ca65-numeric-admission.json'),('ca65_repeat_end','ca65-repeat-end.json'),('ca65_literal_boundaries','ca65-literal-boundaries.json'),('ca65_character_operands','ca65-character-operands.json')]:
   captured=json.loads(git('show',head+':crates/asm198x/tests/fixtures/'+filename))['cases'];result=next(c for c in r['results'] if c['name']==cohort);index=0
   for item in captured:
    assert not item.get('formatter_gap') and not item.get('assembly_gaps')
    accepted=item['native'][-1]['exit']==0;stride=4 if accepted else 1;group=result['runs'][index:index+stride];assert len(group)==stride
    assert group[0]['exit']==(0 if accepted else 1),item['name']
    if accepted:assert all(x['exit']==0 and not x.get('signal') and not x.get('error') for x in group) and group[1]['stdout']==group[2]['stdout'],item['name']
    index+=stride
   assert index==len(result['runs']) and index>0
 if case_name=='ca65_absolute_debug':
  assert cursor==153
  assert sum(len(f['symbol_values']) for f in facts)==121
  assert sum(len(f['expected_lines']) for f in facts)==213
  for fact in facts:
   for name,cost in fact['cycle_costs'].items():
    if '::' in name:continue
    for limit in [cost['max'],cost['max']-1]:
     actual=case['runs'][cursor];cursor+=1
     assert actual['exit']==(0 if limit==cost['max'] else 1)
     assert actual.get('signal') is None and not actual.get('error')
     assert '--listing-json=scope.lst.json' in actual['argv'] and '--debug=scope.debug198x' in actual['argv']
     if limit!=cost['max']:assert 'exceeds its cycle budget' in actual['stderr']
  actual=case['runs'][cursor];cursor+=1
  assert actual['exit']==1 and actual.get('signal') is None and not actual.get('error')
  assert 'names no label with instructions' in actual['stderr']
 assert cursor==expected_runs
 receipt=r['source_lock'];assert receipt['build']['run_attempt']==r['host']['github_attempt'];assert receipt['source_commit']==r['checkout_commit'] and receipt['build']['run_id']==run_id
 for k in ['target','archive','archive_sha256','executable_sha256']:assert receipt[k]==r[k]
 for k in ['committed_lock_sha256','before_lock_sha256','after_lock_sha256']:assert receipt[k]==lock
 wrong=json.loads(path.with_name('wrong-bytes.json').read_text());assert wrong['qualified'] is False
 assert {c['name'] for c in wrong['results'] if c['status']!='pass'}=={'reference_bytes','determinism','structured_success'}
 corrupt=json.loads(path.with_name('corrupt-archive.json').read_text());assert corrupt['qualified'] is False and corrupt['error']=='SHA-256 mismatch for '+r['archive']
 summary.append(dict(target=r['target'],run_attempt=r['host']['github_attempt'],report_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),archive_sha256=r['archive_sha256'],executable_sha256=r['executable_sha256'],cases=expected_total,cohort=case_name,cohort_cases=expected_count,cohort_runs=expected_runs,negative_controls=2))
assert targets==set(meta['targets']) and len(sources)==1
source=sources.pop();assert git('rev-parse',source+'^{tree}')==git('rev-parse',head+'^{tree}')
if source!=head:assert git('rev-parse',source+'^2').decode().strip()==head
result=dict(head=head,checkout=source,run_id=run_id,cargo_lock_sha256=lock,reports=summary)
Path(prefix+'-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
