ca65 now reads ordinary names and nested numeric/string queries at their positions in selected `.if`/`.elseif`/`.ifconst`/`.ifnconst` expressions. The previous text expansion missed reference effects, refused scoped constancy and could allow an unknown size to become valid through a later declaration. Reuse the existing reader, scope resolver and deferred classifier through an opt-in parser context; pure consumers keep their defaults.

The 200-case native audit fixes 72 of 75 measured differences. All 197 supported cases are permanent CLI and required archive coverage (725 commands); the three ordinary-label size cases remain explicit under #798. Normal data-list operands, repeat counts and other consumers remain under #795.

Focused conditional, generated-label provenance and diagnostic-span regressions pass, alongside every prior native match across 2,266 cases, 115 Node checks and lint/docs checks. Full Rust/Lua, a fresh 4510 build, local archive controls and all five actual native archives are required before merge. Intermediate failed/incomplete preflight runs are explicitly retained separately from final qualification.

Refs #795 and #798.
