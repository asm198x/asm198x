import hashlib
import json
import subprocess
from pathlib import Path

producer = Path('/private/tmp/asm198x-conditional-context-final-producer')
baseline = Path('/private/tmp/asm198x-query-admission-producer')
compare = 'docs/plans/2026-10-20-ca65-string-token-provenance/consumer_compare.py'
assert hashlib.sha256((producer/'asm198x').read_bytes()).hexdigest() == (producer/'binary-sha256').read_text().strip()
rows = json.loads((baseline/'replay-summary.json').read_text()) + [
    {'label': 'query-admission', 'facts': 'docs/plans/2026-10-20-ca65-source-query-effects/query-admission-native.json'},
    {'label': 'query-short-circuit', 'facts': str(baseline/'short-circuit-native.json')},
]
summary = []
for row in rows:
    label, facts = row['label'], row['facts']
    names = {r['name'] for r in json.loads(Path(facts).read_text())['cases']}
    matches = [f for f in baseline.glob('*.json') if isinstance((d := json.loads(f.read_text())), dict) and 'results' in d and {r['name'] for r in d['results']} == names and not f.name.endswith('before.json') and not f.name.startswith('new-before')]
    assert len(matches) == 1, (label, matches)
    before = json.loads(matches[0].read_text())
    output = producer/(label+'-after.json')
    subprocess.run(['python3', compare, str(producer/'asm198x'), str(output), '--facts', facts]+(['--flat'] if 'flat-native' in facts else []), check=True)
    after = json.loads(output.read_text())
    old = {r['name']: r for r in before['results']}
    lost = [r['name'] for r in after['results'] if old[r['name']]['matches_native'] and not r['matches_native']]
    summary.append({'label': label, 'facts': facts, 'baseline': str(matches[0]), 'cases': len(names), 'before_matches': sum(r['matches_native'] for r in old.values()), 'after_matches': sum(r['matches_native'] for r in after['results']), 'lost_matches': lost})
    assert not lost, (label, lost)
assert sum(r['cases'] for r in summary) == 2266
(producer/'replay-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
facts = 'docs/plans/2026-10-20-ca65-source-query-effects/conditional-context-native.json'
output = producer/'conditional-after.json'
subprocess.run(['python3', compare, str(producer/'asm198x'), str(output), '--facts', facts], check=True)
actual = json.loads(output.read_text())['results']
assert len(actual) == 200
assert {r['name'] for r in actual if not r['matches_native']} == {'generated_label_size_direct', 'generated_label_size_included', 'generated_label_size_macro'}
print('All 2,266 prior matches retained; 197 supported conditional cases match')
