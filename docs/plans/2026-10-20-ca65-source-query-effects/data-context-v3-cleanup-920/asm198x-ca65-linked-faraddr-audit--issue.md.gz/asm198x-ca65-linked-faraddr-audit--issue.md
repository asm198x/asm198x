Configured ca65 accepts invalid 24-bit far-address values and silently truncates them. `.faraddr -1` emits `ffffff`; `.faraddr $1000000` emits `000000`. Native ca65 V2.18 refuses both outside `[0..16777215]`.

For `input.s`:

```asm
.faraddr -1
```

With `input.cfg`:

```text
MEMORY { MAIN:start=$1000,size=$7000,file=%O; }
SEGMENTS { CODE:load=MAIN,type=ro; }
```

`asm198x --dialect ca65 -C input.cfg input.s -o out.bin` succeeds and writes `ffffff`. Native `ca65 input.s -o input.o` returns a range error. Replacing the operand with `$1000000` wraps to `000000` here.

Forward values also bypass the check:

```asm
.faraddr TARGET
TARGET=-1
```

The 90-case native audit has 51 accepts and 39 refusals. The frozen checked #919 producer (source `9e448f2c`, merged as `75dad590`) and the #920 data candidate both retain 57 native matches and wrongly accept the same 33 cases. These cover eleven invalid shapes in direct, included and invoked-macro source. Positive endpoints, extraction, byte/word and lazy controls retain their matches.

The [configured lowering](https://github.com/asm198x/asm198x/blob/75dad590bd8d3e032729bc596f7d3ab3b49a59aa/crates/asm198x/src/dialects/ca65/mod.rs#L3895) converts each original expression into Lo/Hi/Bank byte expressions before emission. The original 24-bit value is lost before its range is checked. Keep the complete expression through final evaluation; a parse-only check misses forward values. Preserve native byte-extraction and inactive/unused-source behavior.

#906 fixed the flat ca65 path. This issue covers configured `-C` assembly.

Evidence: [all native sources, configs, tool hashes and process streams](https://github.com/asm198x/asm198x/blob/38b55d76fb6238ad50811e1bfb0c6273907a9fbb/docs/plans/2026-10-21-ca65-linked-faraddr/native.json), [checked predecessor comparison](https://github.com/asm198x/asm198x/blob/38b55d76fb6238ad50811e1bfb0c6273907a9fbb/docs/plans/2026-10-21-ca65-linked-faraddr/before.json), [data candidate comparison](https://github.com/asm198x/asm198x/blob/38b55d76fb6238ad50811e1bfb0c6273907a9fbb/docs/plans/2026-10-21-ca65-linked-faraddr/after.json), [reproducible probe](https://github.com/asm198x/asm198x/blob/38b55d76fb6238ad50811e1bfb0c6273907a9fbb/docs/plans/2026-10-21-ca65-linked-faraddr/probe.py), and [capture verification](https://github.com/asm198x/asm198x/blob/38b55d76fb6238ad50811e1bfb0c6273907a9fbb/docs/plans/2026-10-21-ca65-linked-faraddr/capture-verification.json).

A fix should match all 90 controls, preserve prior outputs on refusal, keep native bytes and formatting/debug round trips for valid values, and pass the full workspace and actual native archive gates.
