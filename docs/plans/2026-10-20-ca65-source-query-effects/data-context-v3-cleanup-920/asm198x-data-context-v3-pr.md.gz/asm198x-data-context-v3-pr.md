Data queries now observe earlier reads in their actual expression order. With `VALUE=2`, `.byte .ref(VALUE),.const(VALUE),.ref(VALUE)` emits native `000101`; the last query previously saw no read and emitted `000100`. Queries inside expressions, numeric string arguments, selected token streams and scoped generated names follow the same live reader context.

The context borrows the existing reader and projection, preserving the checked external-binding types, widths and explicit export resolution from #919. Name-only queries remain non-reading; inactive source, unevaluated token predicates and syntax-only formatting retain their existing behavior. No dependencies, public AST fields or object-linking contracts change.

All 515 native data cases match (446 accepts, 69 refusals), fixing 186 measured differences. Every previous native match across 26 matrices / 4,136 cases is retained. The original query matrix now matches all 56 cases and visibility all 274. Both the 1,646-case external fixture and new 515-case data fixture are mandatory package evidence; all 104 cohorts are required.

Validation so far: focused Rust tests, Lua Clippy, formatting, 115 Node/setup tests, docs/version/ecosystem checks, and debug/release native replay pass. The full Lua workspace suite passes 1,643 tests (38 ignored). The local archive passes all 104 cohorts, with exact wrong-byte/checksum/#810 omission-control failures. Fresh 4510 replay matches 564 bytes and fourteen streams and rejects a changed byte. All 29 exact-head checks and five workflow gates are satisfied; actual line coverage is 87.74%. All five actual native reports and source-lock receipts were inspected: each passes all 104 cohorts, including all 1,853 data commands, and rejects both corruption controls.

Supersedes draft #917. Advances #795; its 30 numeric-consumer differences remain a separate following slice. #918 tracks visibility register-token provenance.

The independent configured far-address range audit is tracked in #921 with 90 retained native controls.
