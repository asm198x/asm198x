Merged in #907 after all 29 checks and all five native archive targets passed.

We retain macro definition/invocation frames and physical include paths through flat backend diagnostics, and reject native-invalid unsigned far addresses before emitting bytes. The required cohorts execute 80 diagnostic and 132 far-address cases (464 CLI commands per target). All 96 archive cohorts and both corruption controls passed on every target. The merged tree matches the qualified source.

GitHub could not acquire the first queued Apple Silicon runner; its annotations and the successful second-attempt archive are retained. Complete source, native and local evidence is in `docs/plans/2026-10-20-flat-ca65-faraddr/`; five-host reports are retained in its follow-up qualification folder.
