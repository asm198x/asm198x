import gzip,hashlib,json,shutil,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'docs/plans/2026-10-21-ca65-linked-faraddr/qualification-925';out.mkdir(exist_ok=False)
files=[]
for p in Path('/private/tmp').glob('asm198x-faraddr-*'):
 if p.is_file():files.append(p)
 elif p.name in ['asm198x-faraddr-replay','asm198x-faraddr-extra','asm198x-faraddr-candidates','asm198x-faraddr-4510']:
  files.extend(x for x in p.rglob('*') if x.is_file())
for folder in ['asm198x-faraddr-local-package','asm198x-faraddr-producer']:
 files.extend(p for p in (Path('/private/tmp')/folder).rglob('*') if p.is_file() and p.suffix in ['.json','.log'])
manifest=[]
for p in sorted(set(files)):
 if p.name in ['asm198x-faraddr-ci.log','asm198x-faraddr-ci.json','asm198x-faraddr-acquire.log','asm198x-faraddr-artifacts.json']:continue
 data=p.read_bytes();name=str(p.relative_to('/private/tmp')).replace('/','__')+'.gz';target=out/name;target.write_bytes(gzip.compress(data,mtime=0))
 assert target.stat().st_size<45*1024*1024
 manifest.append(dict(source=str(p),path=name,sha256=hashlib.sha256(data).hexdigest(),stored_sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Retained files:',len(manifest))
extra=repo/'docs/plans/2026-10-21-ca65-canonical-reader';extra.mkdir(exist_ok=False)
for name in ['probe.py','native.json','before.json','after.json']:
 src=Path('/private/tmp/asm198x-canonical-reader-'+name);shutil.copy2(src,extra/name)
p=extra/'probe.py';s=p.read_text().replace("ROOT=Path('/Users/stevehill/Projects/198x/Asm198x/asm198x-ca65-text-consumers')",'ROOT=Path(__file__).resolve().parents[3]');p.write_text(s)
subprocess.run(['python3','-c',"import runpy,json;from pathlib import Path;m=runpy.run_path('docs/plans/2026-10-21-ca65-canonical-reader/probe.py');c=m['cases']();f=json.loads(Path('/private/tmp/asm198x-canonical-reader-native.json').read_text());assert [(k,v) for k,v in c.items()]==[(x['name'],x['source']) for x in f['cases']];assert m['FILES']==f['files'];print('Portable reader probe reproduces all 100 native source/files')"],check=True)
for name in ['full-reader-design.md']:
 data=subprocess.check_output(['git','show','audit/ca65-scalar-context-922:docs/plans/2026-10-21-ca65-generated-fields/'+name]);(extra/name).write_bytes(data)
