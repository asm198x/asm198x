Configured `.faraddr` currently accepts negative or overflowing values and can emit wrong bytes for `*` across page and bank boundaries. For example, `.org $ffff` followed by `.faraddr *` emits `ff0001`; native ca65 emits `ffff00`.

Keep each original address through the configured linker, check its existing unsigned 24-bit range, then emit three little-endian bytes and advance PC once. Flat-family data and explicit byte selectors retain their existing behavior.

All 190 native cases now match, fixing 39 false acceptances and 12 wrong-byte results. The required package cohort covers all cases, diagnostic origins, JSON bytes, formatting round trips and refused-output preservation; Rust also uses the official debug reader. All 4,791 historical cases and 578 additional reader controls preserve checked #920 matches. Focused tests and 115 Node tests pass. Full workspace, release and native archive qualification are in progress; keep this draft until exact-source receipts are retained and all checks pass.

Closes #921.
