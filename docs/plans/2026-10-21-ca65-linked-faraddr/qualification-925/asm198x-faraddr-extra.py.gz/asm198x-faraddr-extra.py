import json,subprocess
from pathlib import Path
out=Path('/private/tmp/asm198x-faraddr-extra')
compare='docs/plans/2026-10-20-ca65-string-token-provenance/consumer_compare.py'
summary=[]
for label,n in [('generated',40),('repeat',18),('scalar',320),('file',200)]:
 rows=[]
 for name,binary in [('before','/private/tmp/asm198x-data-context-v3-producer/asm198x'),('after','/private/tmp/asm198x-scalar-build/debug/asm198x')]:
  p=out/(label+'-'+name+'.json')
  subprocess.run(['python3',compare,binary,str(p),'--facts',str(out/(label+'-native.json'))],check=True,timeout=90)
  r=json.loads(p.read_text())['results'];assert len(r)==n;rows.append({x['name']:x['matches_native'] for x in r})
 b,a=rows;assert b.keys()==a.keys();lost=[k for k in b if b[k] and not a[k]];assert not lost,(label,lost)
 if label=='generated':assert sum(a.values())==40
 summary.append(dict(label=label,cases=n,before_matches=sum(b.values()),after_matches=sum(a.values()),lost_matches=lost))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)
