import json,subprocess,time
from pathlib import Path
out=Path('/private/tmp/asm198x-faraddr-candidates')
targets={'aarch64-apple-darwin','x86_64-apple-darwin','aarch64-unknown-linux-gnu','x86_64-unknown-linux-gnu','x86_64-pc-windows-msvc'}
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
 p=subprocess.run(['gh','api','repos/asm198x/asm198x/actions/runs/39610420467/artifacts'],check=True,capture_output=True,text=True,timeout=35)
 data=json.loads(p.stdout);assert data['total_count']==len(data['artifacts'])<=5
 Path('/private/tmp/asm198x-faraddr-artifacts.json').write_text(json.dumps(data,indent=2)+'\n')
 for a in data['artifacts']:
  assert not a['expired']
  target=a['name'].removeprefix('candidate-qualification-').removesuffix('-1');assert target in targets
  dest=out/target
  if not (dest/'report.json').exists():
   subprocess.run(['gh','run','download','39610420467','--repo','asm198x/asm198x','--name',a['name'],'--dir',str(dest)],check=True,timeout=90)
   print('Downloaded',target,flush=True)
 if {p.parent.name for p in out.glob('*/report.json')}==targets:
  subprocess.run(['python3','/private/tmp/asm198x-audit-faraddr-candidates.py','/private/tmp/asm198x-faraddr','1c7e89d6321ebcc394af15473f6894830aec8e02','39610420467','crates/asm198x/tests/fixtures/ca65-linked-faraddr.json','ca65_linked_faraddr','190','105'],check=True,timeout=90)
  break
 time.sleep(30)
else:raise SystemExit('Native archive receipts not complete within 30 minutes')
