import gzip
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path.cwd()
base = Path('/private/tmp/asm198x-data-context-v3-producer')
out = Path('/private/tmp/asm198x-faraddr-replay')
out.mkdir(exist_ok=True)
binary = Path('/private/tmp/asm198x-scalar-build/debug/asm198x')
comparator = repo / 'docs/plans/2026-10-20-ca65-string-token-provenance/consumer_compare.py'
summary = []
entries = json.loads((base / 'replay-summary.json').read_text())
for entry in entries:
    label = entry['label']
    facts = Path(entry['facts'])
    assert hashlib.sha256(facts.read_bytes()).hexdigest() == entry['facts_sha256']
    baseline = base / (('conditional' if label == 'conditional-context' else label) + '-after.json')
    result = out / (label + '-after.json')
    subprocess.run(['python3', str(comparator), str(binary), str(result), '--facts', str(facts)] + (['--flat'] if label == 'strings-flat-native' else []), check=True, stdout=subprocess.DEVNULL, timeout=240)
    before = json.loads(baseline.read_text())['results']
    after = json.loads(result.read_text())['results']
    assert len(before) == len(after) == entry['cases']
    bm = {r['name']: r.get('matches_native', r.get('matches')) for r in before}
    am = {r['name']: r['matches_native'] for r in after}
    assert bm.keys() == am.keys()
    lost = [n for n in bm if bm[n] and not am[n]]
    assert not lost, (label, lost)
    summary.append(dict(label=label,cases=len(after),before_matches=sum(bm.values()),after_matches=sum(am.values()),lost_matches=lost))
    print(summary[-1],flush=True)
assert len(summary) == 29 and sum(r['cases'] for r in summary) == 4791
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
